const btntrocar = document.getElementById('btn-trocar')
const lampada = document.getElementById('lampada')
let baseURL = "https://e3e91d03-33bf-48bd-9a15-a8c706733cb0-00-21sf194klflkp.worf.replit.dev/"

btntrocar.addEventListener('click', function() {
  if (lampada.src == baseURL + "sigma/lamp0.png") {
    lampada.src = "sigma/lamp1.png"
  } else {
    lampada.src = "sigma/lamp0.png"
  }
})
