const comidas =  document.querySelector('.comidas');

const comida1 = prompt('Digite sua comida nº1')

const comida2 = prompt('Digite sua comida nº2')

comidas.innerText = comida1

comidas.innerText = comida2